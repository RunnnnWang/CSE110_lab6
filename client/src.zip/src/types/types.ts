export type Expense = {
    id: string;
    description: string;
    cost: number;
};

